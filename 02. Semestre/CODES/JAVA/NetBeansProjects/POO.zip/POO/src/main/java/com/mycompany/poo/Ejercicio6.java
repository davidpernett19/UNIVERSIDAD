package com.mycompany.poo;
import java.util.Scanner;

public class Ejercicio6 {
    public static void main (String[] args){
      Scanner tem = new Scanner(System.in);
        int num_1;
        int num_2;
        int num_3;
        System.out.println("RESTA DE DOS NUMEROS");
        System.out.println("Ingrese el primer numero");
        num_1 = tem.nextInt();
        System.out.println("Ingrese el segundo numero");
        num_2 = tem.nextInt();
        num_3 = num_1 % num_2;
        
        System.out.println("El resultado de la resta es " + num_3);
   }
}
