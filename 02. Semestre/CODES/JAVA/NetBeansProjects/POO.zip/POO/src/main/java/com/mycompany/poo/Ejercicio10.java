package com.mycompany.poo;
import java.util.Scanner;
public class Ejercicio10 {
    
    public static void main(String[] args){
        Scanner teclado=new Scanner(System.in);
        int nota1, nota2, nota3;
        System.out.println("Ingrese primer nota: ");
        nota1=teclado.nextInt();
        System.out.println("Ingrese segunda nota: ");
        nota2=teclado.nextInt();
        System.out.println("Ingrese tercera nota: ");
        nota3=teclado.nextInt();
        int promedio=(nota1 + nota2 + nota3)/ 3;
        if (promedio>=0&&promedio<=29){
            System.out.println("PERDIO ");
        }else
            if (promedio>=30&&promedio<=39){
                System.out.println("APROBO, PUEDE MEJORAR ");
            }else
                if (promedio>=40&&promedio<=45){
                  System.out.println("FELICITACIONES ");  
                }else
                    if (promedio>=46&&promedio<=50){
                        System.out.println("HAZ SACADO LA MAXIMA NOTA");
                    } else {
                       System.out.println("NOTA EQUIVOCADA"); 
                    
        }
       
        }
    
    
}
