
package com.mycompany.poo;
import java.util.Scanner;

public class Ejercicio11 {
    public static void main(String[] args){
        Scanner teclado=new Scanner(System.in);
        int estatura1;
        System.out.println("Ingrese su altura");
        estatura1=teclado.nextInt();
        if (estatura1<150){
            System.out.println("ESTATURA BAJA ");
        }else
            if (estatura1>151&&estatura1<=179){
                System.out.println("ESTATURA NORMAL");
            }else
                if (estatura1>180&&estatura1<=210){
                System.out.println("ESTATURA ALTA ");
                }else{
                    System.out.println("ERROR DE NUMERO ");
       
        }
    }
    
}
