package com.mycompany.poo;
import java.util.Scanner;

public class Ejercicio2 {
    public static void main(String[] args) {
    Scanner tem = new Scanner(System.in);
        int num_1;
        int num_2;
        int num_3;
        System.out.println("SUMA DE DOS NUMEROS");
        System.out.println("Ingrese el numero 1: ");
        num_1 = tem.nextInt();
        System.out.println("Ingrese el numero 2: ");
        num_2 = tem.nextInt();
        num_3 = num_1 + num_2;
    System.out.println("El resultado de la suma es " + num_3);
    }
}