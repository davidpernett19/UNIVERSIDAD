package com.mycompany.poo;
import java.util.Scanner;

public class Ejercicio7 {
    public static void main(String[] args) {
        Scanner tem = new Scanner(System.in);
        int num_1;
        int num_2;
        int addition;
        int sustraction;
        int multiplication;
        int divition;
        System.out.println("CALCULADORA");
        System.out.println("Ingrese el primer valor: ");
        num_1 = tem.nextInt();
        System.out.println("Ingrerse el segundo valor: ");
        num_2 = tem.nextInt();
        addition = num_1 + num_2;
        System.out.println("La suma de los numero es: " + addition);
        sustraction = num_1 - num_2;
        System.out.println("La resta de los numeros es: " + sustraction);
        multiplication = num_1 * num_2;
        System.out.println("La multiplicacion de los numeros es: " + multiplication);
        divition = num_1 / num_2;
        System.out.println("La division de los numero es: " + divition);
    }
}