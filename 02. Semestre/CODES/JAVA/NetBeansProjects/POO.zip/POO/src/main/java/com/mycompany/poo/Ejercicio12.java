package com.mycompany.poo;
import java.util.Scanner;

public class Ejercicio12 {
    public static void main(String[] args){
    Scanner teclado=new Scanner (System.in);
    int estatura, peso;
        System.out.println("Ingresa tu estatura");
        estatura=teclado.nextInt();
        System.out.println("Ingrea tu peso");
        peso=teclado.nextInt();{
        if (estatura>=170&& peso<80){
            System.out.println("Bienvenido al equipo");
        }else{
            System.out.println("No pasas al equipo");
            
                    
            }
            
        }
        
        
    }
    
}
