
package com.mycompany.poo;
import java.util.Scanner;

public class Ejercicio9 {

    public static void main(String[] args) {
        Scanner tem = new Scanner(System.in);
        int precio_total;
        int iva_precio;
        int iva_final;
        int precio_final;
        System.out.println("FACTURA CON IVA");
        System.out.println("Ingresa el valor de la factura: ");
        precio_total = tem.nextInt();
        System.out.println("Cuanto es el  IVA? 10, 15, 19 ");
        iva_precio = tem.nextInt();
        iva_final = (precio_total * iva_precio) / 100;
        precio_final = precio_total + iva_final;
        System.out.println("El valor final de tu factura es: " + precio_final);
        

    
    }
}