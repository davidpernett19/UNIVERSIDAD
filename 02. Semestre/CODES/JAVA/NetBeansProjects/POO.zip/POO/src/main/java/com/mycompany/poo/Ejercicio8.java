
package com.mycompany.poo;
import java.util.Scanner;

public class Ejercicio8 {
    public static void main(String[] args) {
        Scanner tem = new Scanner(System.in);
        int num_1;
        int num_2;
        int num_3;
        int final_note;
        System.out.println("NOTA FINAL");
        System.out.println("Escribe la primera nota: ");
        num_1 = tem.nextInt();
        System.out.println("Ingrese la segunda nota: ");
        num_2 = tem.nextInt();
        System.out.println("Ingrese la tercera nota: ");
        num_3 = tem.nextInt();
        final_note =(num_1 + num_2 + num_3) / 3;
        System.out.println("Su nota final  es: " + final_note);
    }
}